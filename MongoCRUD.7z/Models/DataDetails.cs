﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Driver;
using MongoDB.Bson;

namespace MongoCRUD.Models
{
    public class DataDetails
    {
        public String Id { get; set; }
        public string Theme { get; set; }
        public string Name { get; set; }
        public int Functionality { get; set; }
        public int Usability { get; set; }
        public int Efficiency { get; set; }
        public int Maintainability { get; set; }
        public int Durability { get; set; }
        public int QuantityUsers { get; set; }
    }
}