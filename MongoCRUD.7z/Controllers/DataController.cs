﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MongoCRUD.Models;
using MongoDB.Driver;
using MongoDB.Bson;

namespace MongoCRUD.Controllers
{
    public class DataController : Controller
    {
        //[HttpPost]
        // GET: Data
        public ActionResult Index(DataDetails det)
        {
                if (ModelState.IsValid)
                {
                    string constr = ConfigurationManager.AppSettings["connectionString"];
                    var Client = new MongoClient(constr);
                    var DB = Client.GetDatabase("Marketing");
                    var collection = DB.GetCollection<DataDetails>("Marketing");
                    collection.InsertOneAsync(det);
                    return RedirectToAction("dataList");
                }
                return View();            
        }

        public ActionResult dataList()
        {
            string constr = ConfigurationManager.AppSettings["connectionString"];
            var Client = new MongoClient(constr);
            var db = Client.GetDatabase("Marketing");
            var collection = db.GetCollection<DataDetails>("Marketing").Find(new BsonDocument()).ToList();

            return View(collection);
        }
    }
}